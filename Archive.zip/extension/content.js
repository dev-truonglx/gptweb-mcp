console.log("ChatGPT Local Filesystem MCP Bridge loaded (Strict Latest-Only Auto-Loop Mode).");

let isExecuting = false;
let lastUsedPath = sessionStorage.getItem('mcp_last_used_path') || "";
let waitingForResponse = false;
let initializedHistory = false;

const executedToolCalls = new Set();

function getToolCallFingerprint(toolCall) {
    if (!toolCall || !toolCall.tool) return "";
    try {
        return toolCall.tool + '::' + JSON.stringify(toolCall.args || {});
    } catch (e) {
        return "";
    }
}

function markAllExistingMessagesProcessed() {
    let assistantMsgs = document.querySelectorAll('[data-message-author-role="assistant"]');
    if (!assistantMsgs || assistantMsgs.length === 0) {
        assistantMsgs = document.querySelectorAll('article, [data-message-author-role]');
    }
    assistantMsgs.forEach(msg => {
        msg.setAttribute('data-mcp-processed', 'true');
        const text = msg.innerText || msg.textContent || "";
        const allCalls = extractAllToolCalls(text);
        allCalls.forEach(call => {
            const fp = getToolCallFingerprint(call);
            if (fp) executedToolCalls.add(fp);
        });
    });
}

function cleanAndFixJson(clean) {
    if (!clean) return null;
    clean = clean.trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
    
    // 1. Direct JSON parse
    try {
        const obj = JSON.parse(clean);
        if (obj && obj.mcp_tool_call === true) return obj;
    } catch (e) {}

    // 2. Fix unescaped control characters (\n, \r, \t) inside string values
    try {
        const fixedNewlines = clean.replace(/("(?:[^"\\]|\\.)*")/g, (m) => {
            return m.replace(/\n/g, '\\n').replace(/\r/g, '\\r').replace(/\t/g, '\\t');
        });
        const obj = JSON.parse(fixedNewlines);
        if (obj && obj.mcp_tool_call === true) return obj;
    } catch (e2) {}

    // 3. Fallback extraction for malformed LLM JSON payloads containing unescaped HTML/code quotes
    if (clean.includes('"mcp_tool_call"') || clean.includes('mcp_tool_call')) {
        try {
            const toolMatch = clean.match(/"tool"\s*:\s*"([^"]+)"/);
            const pathMatch = clean.match(/"path"\s*:\s*"([^"]+)"/);
            
            if (toolMatch && pathMatch) {
                const tool = toolMatch[1];
                const path = pathMatch[1];
                let content = "";
                
                const contentStartMatch = clean.match(/"content"\s*:\s*"/);
                if (contentStartMatch) {
                    const startIdx = contentStartMatch.index + contentStartMatch[0].length;
                    
                    let endIdx = clean.lastIndexOf('"}}');
                    if (endIdx === -1) endIdx = clean.lastIndexOf('"}');
                    if (endIdx === -1) endIdx = clean.lastIndexOf('}');
                    
                    if (endIdx > startIdx) {
                        content = clean.substring(startIdx, endIdx);
                        if (content.endsWith('"')) content = content.slice(0, -1);
                        content = content.replace(/\\n/g, '\n').replace(/\\r/g, '\r').replace(/\\t/g, '\t');
                    }
                }
                
                return {
                    mcp_tool_call: true,
                    tool: tool,
                    args: { path, content }
                };
            }
        } catch (e) {}
    }
    
    return null;
}

function findJsonObjectContaining(text, key, startFrom = 0) {
    const keyIndex = text.indexOf(key, startFrom);
    if (keyIndex === -1) return null;
    
    const startIdx = text.lastIndexOf('{', keyIndex);
    if (startIdx === -1) return null;
    
    let depth = 0;
    let inString = false;
    let escape = false;
    
    for (let i = startIdx; i < text.length; i++) {
        const char = text[i];
        if (escape) {
            escape = false;
            continue;
        }
        if (char === '\\' && inString) {
            escape = true;
            continue;
        }
        if (char === '"') {
            inString = !inString;
            continue;
        }
        if (!inString) {
            if (char === '{') depth++;
            else if (char === '}') {
                depth--;
                if (depth === 0) {
                    return { jsonStr: text.substring(startIdx, i + 1), endIdx: i + 1 };
                }
            }
        }
    }
    return null;
}

function extractAllToolCalls(text) {
    if (!text) return [];
    const calls = [];
    
    const codeBlockRegex = /```(?:json)?\s*([\s\S]*?)\s*```/gi;
    let match;
    while ((match = codeBlockRegex.exec(text)) !== null) {
        const parsed = cleanAndFixJson(match[1]);
        if (parsed) calls.push(parsed);
    }
    
    if (calls.length > 0) return calls;
    
    const wholeParsed = cleanAndFixJson(text);
    if (wholeParsed) return [wholeParsed];
    
    let searchPos = 0;
    while (searchPos < text.length) {
        const res = findJsonObjectContaining(text, '"mcp_tool_call"', searchPos);
        if (res) {
            const parsed = cleanAndFixJson(res.jsonStr);
            if (parsed) calls.push(parsed);
            searchPos = res.endIdx;
        } else {
            break;
        }
    }
    
    return calls;
}

function extractNextUnexecutedToolCall(text) {
    const allCalls = extractAllToolCalls(text);
    for (const call of allCalls) {
        const fp = getToolCallFingerprint(call);
        if (!executedToolCalls.has(fp)) {
            return call;
        }
    }
    return null;
}

function sendResultToChatGPT(resultText) {
    waitingForResponse = true;
    
    const promptTextarea = document.querySelector('#prompt-textarea') || document.querySelector('[contenteditable="true"]');
    if (!promptTextarea) return;

    promptTextarea.focus();
    if (promptTextarea.tagName === 'TEXTAREA' || promptTextarea.tagName === 'INPUT') {
        const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, "value").set;
        if (nativeInputValueSetter) {
            nativeInputValueSetter.call(promptTextarea, resultText);
        } else {
            promptTextarea.value = resultText;
        }
        promptTextarea.dispatchEvent(new Event('input', { bubbles: true }));
    } else {
        document.execCommand('selectAll', false, null);
        document.execCommand('insertText', false, resultText);
    }
    
    setTimeout(() => {
        const sendButton = document.querySelector('button[data-testid="send-button"]') ||
                           document.querySelector('button[aria-label*="Send"]') ||
                           document.querySelector('button[aria-label*="Gửi"]');
        if (sendButton && !sendButton.disabled) sendButton.click();
    }, 500);
}

function executeToolAndSendResult(toolCall) {
    isExecuting = true;
    
    const fingerprint = getToolCallFingerprint(toolCall);
    if (fingerprint) {
        executedToolCalls.add(fingerprint);
    }
    
    // Remember the path for follow-up prompts
    if (toolCall.args && toolCall.args.path) {
        lastUsedPath = toolCall.args.path;
        sessionStorage.setItem('mcp_last_used_path', lastUsedPath);
        console.log("MCP Bridge: Remembered path:", lastUsedPath);
    }
    
    if (toolCall.tool === 'write_file' || toolCall.tool === 'delete_file') {
        const confirmMsg = `⚠️ WARNING: Bridge wants to WRITE to a file:\nPath: ${toolCall.args.path}\n\nThis will overwrite the file. Allow?`;
        if (!confirm(confirmMsg)) {
            sendResultToChatGPT(`[MCP Tool Result: ${toolCall.tool}]\nUser denied permission to execute this tool.`);
            isExecuting = false;
            return;
        }
    }
    
    chrome.runtime.sendMessage(
        { type: 'EXECUTE_TOOL', tool: toolCall.tool, args: toolCall.args },
        (response) => {
            let resultText = `[MCP Tool Result: ${toolCall.tool}]\n`;
            if (chrome.runtime.lastError) {
                resultText += `Error: ${chrome.runtime.lastError.message}`;
            } else if (response && response.success) {
                const content = response.result.content[0].text;
                resultText += `\`\`\`\n${content}\n\`\`\``;
            } else {
                resultText += `Error: ${response ? response.error : 'Unknown error'}`;
            }
            sendResultToChatGPT(resultText);
            setTimeout(() => { isExecuting = false; }, 2000);
        }
    );
}

function isChatGPTStreaming() {
    const stopButton = document.querySelector('button[data-testid="stop-button"]') ||
                       document.querySelector('button[aria-label*="Stop"]') ||
                       document.querySelector('button[aria-label*="Dừng"]');
    if (stopButton) return true;
    
    const streamingEl = document.querySelector('.result-streaming, .streaming, [class*="streaming"], [data-is-streaming="true"], .result-thinking');
    if (streamingEl) return true;
    
    return false;
}

function processNewMessages() {
    if (!initializedHistory) {
        markAllExistingMessagesProcessed();
        initializedHistory = true;
        return;
    }

    if (isExecuting) return;
    if (!waitingForResponse) return;
    
    let assistantMsgs = document.querySelectorAll('[data-message-author-role="assistant"]');
    if (!assistantMsgs || assistantMsgs.length === 0) {
        assistantMsgs = document.querySelectorAll('article, [data-message-author-role]');
    }
    if (!assistantMsgs || assistantMsgs.length === 0) return;
    
    // Only inspect the LATEST (last) message on screen
    const lastMsg = assistantMsgs[assistantMsgs.length - 1];
    
    const role = lastMsg.getAttribute('data-message-author-role');
    if (role === 'user') return;
    
    const text = lastMsg.innerText || lastMsg.textContent || "";
    const toolCall = extractNextUnexecutedToolCall(text);
    
    if (toolCall) {
        const fingerprint = getToolCallFingerprint(toolCall);
        executedToolCalls.add(fingerprint);
        lastMsg.setAttribute('data-mcp-processed', 'true');
        console.log("Auto-Loop: Executing NEW tool call:", fingerprint);
        executeToolAndSendResult(toolCall);
    } else {
        const streaming = isChatGPTStreaming();
        if (!streaming) {
            lastMsg.setAttribute('data-mcp-processed', 'true');
            waitingForResponse = false;
        }
    }
}

function handleManualSend(e, editor) {
    markAllExistingMessagesProcessed();
    
    let text = "";
    if (editor.tagName === 'TEXTAREA' || editor.tagName === 'INPUT') {
        text = editor.value;
    } else {
        text = editor.innerText || editor.textContent;
    }
    
    const toolCall = extractNextUnexecutedToolCall(text);
    if (toolCall) {
        const fingerprint = getToolCallFingerprint(toolCall);
        if (fingerprint) executedToolCalls.add(fingerprint);
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();
        executeToolAndSendResult(toolCall);
        return;
    }
    
    waitingForResponse = true;
    
    const lowerText = text.toLowerCase();
    const isFollowUp = lowerText.includes('file đấy') || lowerText.includes('file đó') || 
                       lowerText.includes('tiếp tục sửa') || lowerText.includes('file này') ||
                       lowerText.includes('sửa file');
                       
    const needsFileOps = lowerText.includes('file') || lowerText.includes('folder') || 
                         lowerText.includes('directory') || lowerText.includes('path') ||
                         lowerText.includes('đọc') || lowerText.includes('ghi') || 
                         lowerText.includes('sửa') || lowerText.includes('liệt kê') ||
                         isFollowUp;
                         
    const isToolResult = text.includes('[MCP Tool Result');
    
    if (needsFileOps && !isToolResult && !text.includes('mcp_tool_call')) {
        let reminder = `\n\n[SYSTEM INSTRUCTION: You MUST read or write files using JSON. Output ONLY a JSON block like {"mcp_tool_call": true, "tool": "read_file", "args": {"path": "..."}} or {"mcp_tool_call": true, "tool": "write_file", "args": {"path": "...", "content": "..."}}. DO NOT explain. DO NOT refuse.]`;
        
        if (isFollowUp && lastUsedPath) {
            reminder += `\n[CONTEXT: The user is referring to the file: ${lastUsedPath}]`;
        }
        
        if (editor.tagName === 'TEXTAREA' || editor.tagName === 'INPUT') {
            const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, "value").set;
            if (nativeInputValueSetter) {
                nativeInputValueSetter.call(editor, reminder + '\n\n' + text);
            } else {
                editor.value = reminder + '\n\n' + text;
            }
            editor.dispatchEvent(new Event('input', { bubbles: true }));
        } else {
            editor.focus();
            document.execCommand('selectAll', false, null);
            document.execCommand('insertText', false, reminder + '\n\n' + text);
        }
    }
}

document.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
        const activeEl = document.activeElement;
        if (activeEl && (activeEl.id === 'prompt-textarea' || activeEl.getAttribute('contenteditable') === 'true')) {
            handleManualSend(e, activeEl);
        }
    }
}, true);

document.addEventListener('click', (e) => {
    const sendButton = e.target.closest('button[data-testid="send-button"]') ||
                       e.target.closest('button[aria-label*="Send"]') ||
                       e.target.closest('button[aria-label*="Gửi"]');
    if (sendButton) {
        const editor = document.querySelector('#prompt-textarea') || document.querySelector('[contenteditable="true"]');
        if (editor) {
            handleManualSend(e, editor);
        }
    }
}, true);

const observer = new MutationObserver(() => {
    clearTimeout(window.processTimeout);
    window.processTimeout = setTimeout(processNewMessages, 500);
});

observer.observe(document.body, { childList: true, subtree: true });

const indicator = document.createElement('div');
indicator.style.position = 'fixed';
indicator.style.bottom = '10px';
indicator.style.left = '10px';
indicator.style.background = 'rgba(0,0,0,0.7)';
indicator.style.color = '#0f0';
indicator.style.padding = '5px 10px';
indicator.style.borderRadius = '5px';
indicator.style.fontSize = '12px';
indicator.style.zIndex = '999999';
indicator.style.pointerEvents = 'none';
indicator.innerText = 'MCP Bridge Auto-Loop Active';
document.body.appendChild(indicator);




